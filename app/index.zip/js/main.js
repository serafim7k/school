var answer_1 = document.getElementById('answer_1');
var answer_2 = document.getElementById('answer_2');
var answer_3 = document.getElementById('answer_3');
var answer_4 = document.getElementById('answer_4');
var answer_5 = document.getElementById('answer_5');
var answer_6 = document.getElementById('answer_6');
var answer_7 = document.getElementById('answer_7');
var answer_8 = document.getElementById('answer_8');
var answer_9 = document.getElementById('answer_9');
var answer_10 = document.getElementById('answer_10');
var True = true;
var False = false;

////////////////////////////////////////////////////////////////

function its_false(param) {
  if (answer_1 == True) {
    False = True;
  }
  else{
    True = False;
  }
  param.innerHTML = False;
}

function its_true(param) {
  if (answer_1 == False) {
    True = False;
  }
  else{
    False = True;
  }
  param.innerHTML = True;
}

///////////////////////////////////////////////////////////

var True_2 = true;
var False_2 = false;

function its_false_2(param) {
  if (answer_2 == True_2) {
    False_2 = True_2;
  }
  else{
    True_2 = False_2;
  }
  param.innerHTML = False_2;
}

function its_true_2(param) {
  if (answer_2 == False_2) {
    True_2 = False_2;
  }
  else{
    False_2 = True_2;
  }
  param.innerHTML = True_2;
}

///////////////////////////////////////////////////////////

var True_3 = true;
var False_3 = false;

function its_false_3(param) {
  if (answer_3 == True_3) {
    False_3 = True_3;
  }
  else{
    True_3 = False_3;
  }
  param.innerHTML = False_3;
}

function its_true_3(param) {
  if (answer_3 == False_3) {
    True_3 = False_3;
  }
  else{
    False_3 = True_3;
  }
  param.innerHTML = True_3;
}

///////////////////////////////////////////////////////////

var True_4 = true;
var False_4 = false;

function its_false_4(param) {
  if (answer_4 == True_4) {
    False_4 = True_4;
  }
  else{
    True_4 = False_4;
  }
  param.innerHTML = False_4;
}

function its_true_4(param) {
  if (answer_4 == False_4) {
    True_4 = False_4;
  }
  else{
    False_4 = True_4;
  }
  param.innerHTML = True_4;
}

///////////////////////////////////////////////////////////

var True_5 = true;
var False_5 = false;

function its_false_5(param) {
  if (answer_5 == True_5) {
    False_5 = True_5;
  }
  else{
    True_5 = False_5;
  }
  param.innerHTML = False_5;
}

function its_true_5(param) {
  if (answer_5 == False_5) {
    True_5 = False_5;
  }
  else{
    False_5 = True_5;
  }
  param.innerHTML = True_5;
}

///////////////////////////////////////////////////////////

var True_6 = true;
var False_6 = false;

function its_false_6(param) {
  if (answer_6 == True_6) {
    False_6 = True_6;
  }
  else{
    True_6 = False_6;
  }
  param.innerHTML = False_6;
}

function its_true_6(param) {
  if (answer_6 == False_6) {
    True_6 = False_6;
  }
  else{
    False_6 = True_6;
  }
  param.innerHTML = True_6;
}

///////////////////////////////////////////////////////////

var True_7 = true;
var False_7 = false;

function its_false_7(param) {
  if (answer_7 == True_7) {
    False_7 = True_7;
  }
  else{
    True_7 = False_7;
  }
  param.innerHTML = False_7;
}

function its_true_7(param) {
  if (answer_7 == False_7) {
    True_7 = False_7;
  }
  else{
    False_7 = True_7;
  }
  param.innerHTML = True_7;
}

///////////////////////////////////////////////////////////

var True_8 = true;
var False_8 = false;

function its_false_8(param) {
  if (answer_8 == True_8) {
    False_8 = True_8;
  }
  else{
    True_8 = False_8;
  }
  param.innerHTML = False_8;
}

function its_true_8(param) {
  if (answer_8 == False_8) {
    True_8 = False_8;
  }
  else{
    False_8 = True_8;
  }
  param.innerHTML = True_8;
}

///////////////////////////////////////////////////////////

var True_9 = true;
var False_9 = false;

function its_false_9(param) {
  if (answer_9 == True_9) {
    False_9 = True_9;
  }
  else{
    True_9 = False_9;
  }
  param.innerHTML = False_9;
}

function its_true_9(param) {
  if (answer_9 == False_9) {
    True_9 = False_9;
  }
  else{
    False_9 = True_9;
  }
  param.innerHTML = True_9;
}

///////////////////////////////////////////////////////////

var True_10 = true;
var False_10 = false;

function its_false_10(param) {
  if (answer_10 == True_10) {
    False_10 = True_10;
  }
  else{
    True_10 = False_10;
  }
  param.innerHTML = False_10;
}

function its_true_10(param) {
  if (answer_10 == False_10) {
    True_10 = False_10;
  }
  else{
    False_10 = True_10;
  }
  param.innerHTML = True_10;
}
